/*
	
	Aslan Oztreves
	Timing 
	PROGRAMMING ASSIGNMENT 1
	02/17/2017

*/
#ifndef timing_h
#define timing_h

#include <stdio.h>
class timing{
private:
public:
    timing();
	void timingForArrayList();
	void timingForArrayStack();
	void timingForPointerList();
	void timingForPointerStack();
    void timingForLibaryList();
    void timingForLibaryStack();
};
#endif
