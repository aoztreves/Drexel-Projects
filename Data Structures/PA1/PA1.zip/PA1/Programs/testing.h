/*
	
	Aslan Oztreves
	Testing
	PROGRAMMING ASSIGNMENT 1
	02/17/2017

*/
#ifndef testing_h
#define testing_h

#include <stdio.h>
class testing{
private:
public:
    testing();
	void testingForArrayList();
	void testingForArrayStack();
	void testingForPointerList();
	void testingForPointerStack();
    
};
#endif
