//
//  timing.hpp
//  asd
//
//  Created by Aslan Oztreves on 3/6/17.
//  Copyright © 2017 Aslan Oztreves. All rights reserved.
//

#ifndef timing_h
#define timing_h

#include <stdio.h>
class timing{
private:
    
public:
    timing();
    void timeforLCRSTree();
    void timeforLOCTree();
};

#endif /* timing_h */
