//
//  concatenatelist.hpp
//  pa1
//
//  Created by Aslan Oztreves on 3/5/17.
//  Copyright © 2017 Aslan Oztreves. All rights reserved.
//

#ifndef listconcat_hpp
#define listconcat_hpp

#include <stdio.h>

class concatenatelist
{
private:
    int eofL;
public:
    concatenatelist();
    void concatenateList();
};

#endif /* concatenatelist_hpp */
