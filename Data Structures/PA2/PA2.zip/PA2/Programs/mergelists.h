/*
	
	Aslan Oztreves
	Lists: array implementation of operations:
	FIRST, END, RETRIEVE, LOCATE, NEXT, PREVIOUS, INSERT, DELETE, MAKENULL
	PROGRAMMING ASSIGNMENT 1
	02/17/2017
 
 */
#ifndef mergelists_hpp
#define mergelists_hpp
#include <stdio.h>

class sortedList
{
private:
    int array1[1000];
    int array2[1000];
    int array3[1000];
    int array4[1000];
    int eofL;
public:
    sortedList();
    void nSortedList();
};
#endif
