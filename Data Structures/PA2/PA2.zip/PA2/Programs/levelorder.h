//
//  levelorder.hpp
//  pa2-done
//
//  Created by Aslan Oztreves on 3/7/17.
//  Copyright © 2017 Aslan Oztreves. All rights reserved.
//

#ifndef levelorder_hpp
#define levelorder_hpp

#include <stdio.h>
#include "tNode.h"
#include "node.h"
class levelorder
{
    private:
    
    public:
    levelorder();
    void levelOrder();
};

#endif /* levelorder_hpp */
