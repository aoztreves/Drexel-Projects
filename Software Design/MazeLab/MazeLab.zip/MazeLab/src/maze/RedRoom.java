package maze;

import java.awt.Color;

public class RedRoom extends Room{

	public RedRoom(int num) {
		super(num);
		// TODO Auto-generated constructor stub
	}
	public Color getColor()
	{
		return Color.RED;
	}
	public void enter()
	{
		super.notifyEntryListeners();
	}
	
}
