package maze;

import java.awt.Color;

public class GreenRoom extends Room{
	public GreenRoom(int num){
		super(num);
	}
	public Color getColor(){
		return Color.GREEN;
	}
}
