package maze;

import java.awt.Color;

public class BlueWall extends Wall{
	public Color getColor()
	{
		return Color.BLUE;
	}

}
