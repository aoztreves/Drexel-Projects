package maze;

import java.util.Scanner;
import java.io.*;
import java.util.Vector;

public class BlueMazeGameCreator extends MazeGameCreator{
	public static Maze createMaze()
	{
		
		Maze maze = new Maze();
		GreenRoom room0 = new GreenRoom(0);
		GreenRoom room1 = new GreenRoom(1);
		//RedRoom room2 = new RedRoom(2);
		
		BlueWall wall = new BlueWall();
		BrownDoor door = new BrownDoor(room0,room1);
		
		room0.setSide(Direction.North, MakeWall());
		room0.setSide(Direction.East, MakeDoor(room0,room1));
		room0.setSide(Direction.South, MakeWall());
		room0.setSide(Direction.West, MakeWall());
		
		room1.setSide(Direction.North, MakeWall());
		room1.setSide(Direction.East, MakeWall());
		room1.setSide(Direction.South, MakeWall());
		room1.setSide(Direction.West, MakeDoor(room0,room1));
			
		maze.addRoom(room0);
		maze.addRoom(room1);
		//maze.addRoom(room2);
		
		maze.setCurrentRoom(0);
		System.out.println("Maze with 2 rooms");
		
		System.out.println("Number of rooms: " + maze.getNumberOfRooms());
		
				
		return maze;
		
	}
	public static Door MakeDoor(Room r1,Room r2){
		System.out.print(r1 + " "+ r2);
		BrownDoor door =new BrownDoor(r1,r2);
		
		return door;
	}
	public static Wall MakeWall(){
		BlueWall bwall = new BlueWall();
		return bwall;
	}
	public static Room MakeRoom(int roomNum){
		GreenRoom groom = new GreenRoom(roomNum);
		System.out.println("this is room :" + roomNum);
		return groom;
	}
	public static Maze MakeMaze() throws IOException {
		Maze maze = new Maze();
		
		int roomNum =0;
		String answer1 ="N";
		while(answer1 == "N"){
			if(roomNum > 0){
				System.out.println("Do you want one more Room (Y/N)? ");
		        BufferedReader answer_in = new BufferedReader(new InputStreamReader(System.in));
		        answer1 = answer_in.readLine();
		        if(answer1.equals("Y")){
		        	
		        	System.out.println("Where do you want the door for this and one previous room (N/E/S/W)? ");
			        BufferedReader answer_in2 = new BufferedReader(new InputStreamReader(System.in));
			        String answer2 = answer_in2.readLine();
			        
			        if(answer2=="N"){
			        	MakeRoom(roomNum).setSide(Direction.North, MakeDoor(MakeRoom(roomNum-1),MakeRoom(roomNum)));
			        	MakeRoom(roomNum).setSide(Direction.East, MakeWall());
			        	MakeRoom(roomNum).setSide(Direction.South, MakeWall());
			        	MakeRoom(roomNum).setSide(Direction.West, MakeWall());
			        }
			        else if(answer2 == "E"){
			        	MakeRoom(roomNum).setSide(Direction.North, MakeWall());
			        	MakeRoom(roomNum).setSide(Direction.East, MakeDoor(MakeRoom(roomNum-1),MakeRoom(roomNum)));
			        	MakeRoom(roomNum).setSide(Direction.South, MakeWall());
			        	MakeRoom(roomNum).setSide(Direction.West, MakeWall());
			        }
			        else if(answer2 == "S"){
			        	MakeRoom(roomNum).setSide(Direction.North, MakeWall());
			        	MakeRoom(roomNum).setSide(Direction.East, MakeWall());
			        	MakeRoom(roomNum).setSide(Direction.South, MakeDoor(MakeRoom(roomNum-1),MakeRoom(roomNum)));
			        	MakeRoom(roomNum).setSide(Direction.West, MakeWall());
			        }
			        else if(answer2 == "W"){
			        	MakeRoom(roomNum).setSide(Direction.North, MakeWall());
			        	MakeRoom(roomNum).setSide(Direction.East, MakeWall());
			        	MakeRoom(roomNum).setSide(Direction.South, MakeWall());
			        	MakeRoom(roomNum).setSide(Direction.West, MakeDoor(MakeRoom(roomNum-1),MakeRoom(roomNum)));
			        }
			        
			        roomNum++;
			        //System.out.println(maze.getNumberOfRooms());
		        }
			}
			else{
				System.out.println("Where do you want the door for this room (N/E/S/W)? ");
		        BufferedReader answer_in3 = new BufferedReader(new InputStreamReader(System.in));
		        String answer3 = answer_in3.readLine();
		        
		        if(answer3=="N"){
		        	MakeRoom(roomNum).setSide(Direction.North, MakeDoor(MakeRoom(roomNum),MakeRoom(roomNum+1)));
		        	MakeRoom(roomNum).setSide(Direction.East, MakeWall());
		        	MakeRoom(roomNum).setSide(Direction.South, MakeWall());
		        	MakeRoom(roomNum).setSide(Direction.West, MakeWall());
		        }
		        else if(answer3=="E"){
		        	MakeRoom(roomNum).setSide(Direction.North, MakeWall());
		        	MakeRoom(roomNum).setSide(Direction.East, MakeDoor(MakeRoom(roomNum),MakeRoom(roomNum+1)));
		        	MakeRoom(roomNum).setSide(Direction.South, MakeWall());
		        	MakeRoom(roomNum).setSide(Direction.West, MakeWall());
		        }
		        else if(answer3=="S"){
		        	MakeRoom(roomNum).setSide(Direction.North, MakeWall());
		        	MakeRoom(roomNum).setSide(Direction.East, MakeWall());
		        	MakeRoom(roomNum).setSide(Direction.South, MakeDoor(MakeRoom(roomNum),MakeRoom(roomNum+1)));
		        	MakeRoom(roomNum).setSide(Direction.West, MakeWall());
		        }
		        else if(answer3 == "W"){
		        	MakeRoom(roomNum).setSide(Direction.North, MakeWall());
		        	MakeRoom(roomNum).setSide(Direction.East, MakeWall());
		        	MakeRoom(roomNum).setSide(Direction.South, MakeWall());
		        	MakeRoom(roomNum).setSide(Direction.West, MakeDoor(MakeRoom(roomNum),MakeRoom(roomNum+1)));
		        }
		        
		        roomNum++;
				//System.out.println(maze.getNumberOfRooms());
			}
		}
		System.out.println(roomNum);
		for(int i = 0; i <= roomNum-1; i++){
            maze.addRoom(MakeRoom(i));
        }
		maze.setCurrentRoom(0);
        return maze;
	}
}
