
/**
 * 
 * @author Sunny
 * @version 1.0
 * @since 1.0
 */
/*
 * SimpleMazeGame.java
 * Copyright (c) 2008, Drexel University.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Drexel University nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY DREXEL UNIVERSITY ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL DREXEL UNIVERSITY BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package maze;

import maze.ui.MazeViewer;
import java.util.Scanner;
import java.io.*;
import java.util.Vector;
/**
 * 
 * @author Sunny
 * @version 1.0
 * @since 1.0
 */
public class MazeGameCreator 
{
	/**
	 * Creates a small maze.
	 */
	public static Maze createMaze()
	{
		
		Maze maze = new Maze();
		RedRoom room0 = new RedRoom(0);
		RedRoom room1 = new RedRoom(1);
		//Room room2 = new Room(2);
		
		RedWall wall = new RedWall();
		Door door = new Door(room0,room1);
		
		room0.setSide(Direction.North, wall);
		room0.setSide(Direction.East, door);
		room0.setSide(Direction.South, wall);
		room0.setSide(Direction.West, wall);
		
		room1.setSide(Direction.North, wall);
		room1.setSide(Direction.East, wall);
		room1.setSide(Direction.South, wall);
		room1.setSide(Direction.West, door);
		
				
		maze.addRoom(room0);
		maze.addRoom(room1);
	
		
		maze.setCurrentRoom(0);
		System.out.println("Maze with 2 rooms");
		
		System.out.println("Number of rooms: " + maze.getNumberOfRooms());
		
				
		return maze;
		

	}
	public static Maze loadMaze(final String path) throws IOException{
		
		Maze maze = new Maze();
        Vector<String[]> words = new Vector<String[]>();
        Vector<Room> rooms = new Vector<Room>();
        Vector<Door> doors = new Vector<Door>();
        Wall wall = new Wall();
        
        
        String fileName = path;
        BufferedReader reader = new BufferedReader( new FileReader(fileName) );
        String line = reader.readLine();
        String[] rs;
        String[] rs2;
        
        while(line != null){
        	rs = line.split(" ");
        	words.add(rs);
        	line=reader.readLine();
        }
        for(int i=0;i<words.size();i++){
        	rs=words.get(i);
        	
        	if(rs[0].equals("room")){
        		Room tempRoom = new Room(Integer.parseInt(rs[1]));
        		for(int k= 2; k<rs.length ; k++){
        			if(rs[k].equals("wall")){
        				switch(k){
    					case 2:
    						tempRoom.setSide(Direction.North, wall);
    						break;
    					case 3:
    						tempRoom.setSide(Direction.South, wall);
    						break;
    					case 4:
    						tempRoom.setSide(Direction.East, wall);
    						break;
    					case 5:
    						tempRoom.setSide(Direction.West, wall);
    						break;
        				}
        			}
        		}
        		rooms.add(tempRoom);
        	}
        	else if(rs[0].equals("door")){
                int roomNum1 = Integer.parseInt(rs[2]);
                int roomNum2 = Integer.parseInt(rs[3]);
                Door tempDoor = new Door(rooms.get(roomNum1), rooms.get(roomNum2));
                if(rs[4].equals("open")){
                        tempDoor.setOpen(true);
                }
                else{
                	tempDoor.setOpen(false);
                }
            doors.add(tempDoor);
        	}
    	}
        for(int i = 0; i < words.size(); i++){
            int doorNum;
            rs = words.get(i);
            if(rs[0].equals("room")){ 
            	Room tempRoom = rooms.get(Integer.parseInt(rs[1]));
                    for(int j = 2; j < rs.length; j++){
                        if(rs[j].matches("d.*")){
                        	rs2 = rs[j].split("d");
                            doorNum = Integer.parseInt(rs2[1]);
                            switch(j){
        					case 2:
        						tempRoom.setSide(Direction.North, doors.get(doorNum));
        						break;
        					case 3:
        						tempRoom.setSide(Direction.South, doors.get(doorNum));
        						break;
        					case 4:
        						tempRoom.setSide(Direction.East, doors.get(doorNum));
        						break;
        					case 5:
        						tempRoom.setSide(Direction.West, doors.get(doorNum));
        						break;
                            }        
                        }
                    }
            rooms.set(Integer.parseInt(rs[1]), tempRoom);
            }
        }
        for(int i = 0; i < words.size(); i++){
            int roomNum;
            rs = words.get(i);
            if(rs[0].equals("room")){ 
            	Room tempRoom = rooms.get(Integer.parseInt(rs[1]));
                    for(int j = 2; j < rs.length; j++){
                        if(rs[j].matches("[0-9]*")){ 
                        	roomNum = Integer.parseInt(rs[j]);
                                
                            switch(j){
            				case 2:
            					tempRoom.setSide(Direction.North, rooms.get(roomNum));
            					break;
            				case 3:
            					tempRoom.setSide(Direction.South, rooms.get(roomNum));
            					break;
            				case 4:
            					tempRoom.setSide(Direction.East, rooms.get(roomNum));
            					break;
            				case 5:
            					tempRoom.setSide(Direction.West, rooms.get(roomNum));
            					break;
                			}	
                        }
                    }
            rooms.set(Integer.parseInt(rs[1]), tempRoom);
            }
        }
        for(int i = 0; i < rooms.size(); i++){
            maze.addRoom(rooms.get(i));
        }
   
        maze.setCurrentRoom(0);
        
        return maze;
		
	}
	

	public static void main(String[] args) throws IOException
	{
			
		System.out.println("Do you want to create, load or make a maze(create/load/make): ");
        BufferedReader answer_in = new BufferedReader(new InputStreamReader(System.in));
        
        String answer1 = answer_in.readLine();
        System.out.println("Do you want to "+ answer1 + "red, blue or basic (red/blue/basic) maze" );
        String answer2 = answer_in.readLine();
        if(answer1.equals("load"))
        {
            System.out.println("Filename?");
            BufferedReader file_in = new BufferedReader(new InputStreamReader(System.in));
            String input_path = file_in.readLine();
            Maze maze = loadMaze(input_path);
            MazeViewer viewer = new MazeViewer(maze);
            viewer.run();
        }
        else if(answer1.equals("create"))
        {
        	
        		if(answer2.equals("red")){
	        		RedMazeGameCreator rmaze = new RedMazeGameCreator();
	        		Maze maze = rmaze.createMaze();
	                MazeViewer viewer = new MazeViewer(maze);
	                viewer.run();
	        	}
	        	else if(answer2.equals("blue")){
	        		BlueMazeGameCreator bmaze = new BlueMazeGameCreator();
	        		Maze maze = bmaze.createMaze();
	                MazeViewer viewer = new MazeViewer(maze);
	                viewer.run();
	        	}
	        	else{
	        		Maze maze = createMaze();
	        		MazeViewer viewer = new MazeViewer(maze);
	        		viewer.run();
	        	}
	        }
        else{
        	
        		if(answer2.equals("red")){
	        		RedMazeGameCreator rmaze = new RedMazeGameCreator();
	        		Maze maze = rmaze.MakeMaze();
	                MazeViewer viewer = new MazeViewer(maze);
	                viewer.run();
	        	}
	        	else if(answer2.equals("blue")){
	        		BlueMazeGameCreator bmaze = new BlueMazeGameCreator();
	        		Maze maze = bmaze.MakeMaze();
	                MazeViewer viewer = new MazeViewer(maze);
	                viewer.run();
	        	}
	        	
        }
        
	}
}

