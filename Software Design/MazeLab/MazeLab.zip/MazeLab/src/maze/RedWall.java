package maze;

import java.awt.Color;

public class RedWall extends Wall{
	
	public void enter()
	{
		System.out.println("Ouch! Ran into a red wall.");
	}
	
	public Color getColor()
	{
		return Color.RED;
	}
}
