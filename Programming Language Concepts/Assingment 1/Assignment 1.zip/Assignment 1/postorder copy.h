//
//  postorder.hpp
//  pa2-done
//
//  Created by Aslan Oztreves on 3/6/17.
//  Copyright © 2017 Aslan Oztreves. All rights reserved.
//

#ifndef postorder_h
#define postorder_h

#include <stdio.h>
#include <string>
using namespace std;


class postorder
{
private:
   
public:
    
    postorder();
    int mainpostorder();
    bool Number(char &exp);
    
};

#endif /* postorder_h */
