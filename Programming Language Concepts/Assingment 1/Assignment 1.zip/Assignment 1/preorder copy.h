//
//  preorder.hpp
//  pa2-done
//
//  Created by Aslan Oztreves on 3/6/17.
//  Copyright © 2017 Aslan Oztreves. All rights reserved.
//

#ifndef preorder_h
#define preorder_h

#include <stdio.h>


class preorder
{
private:
    
public:
    
    preorder();
    int mainpreorder();
    void reverseArray(char arr[]);
    bool Number(char &exp);
    
};


#endif /* preorder_h */
